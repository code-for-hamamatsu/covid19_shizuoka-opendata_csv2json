
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.18.2'
version = '1.18.2'
full_version = '1.18.2'
git_revision = 'df256d0d2f3bc6833699529824781c58f9c6e697'
release = True

if not release:
    version = full_version
